import React from 'react'
import { render } from 'react-dom'

render(
	<div>
	</div>,
	document.getElementById('react-container')
)